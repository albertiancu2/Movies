import logo from './logo.svg';
import React, {useState, useEffect} from 'react'
import axios from 'axios'
import { useIdleTimer } from 'react-idle-timer'

import LogIn from './components/LogIn'
import MainPage from './components/MainPage'


function App() {

  const [currUser, setUser] = useState({username: ''});
  // const [session, setSession] = useState(null)

  // axios.defaults.withCredentials = true

  const authListener = () => {
    // axios.get("http://localhost:8000/usersWS/islogged/")
    //   .then(user => {
    //       if (user.data !== '') {
    //         setUser(({username: user.data}))
    //     }
    //     else {
    //         setUser("")
    //     }
    //   });
      if (localStorage.getItem('username')) {
        setUser({username: localStorage.getItem('username')})
      }
      else {
        setUser({username: ''})
      }
  }
  
    useEffect( () => {
        authListener();
    }, [])


  return (
    <div className="App">
      {
        currUser.username !== "" ?
          <MainPage setUser={setUser}/>
        :
          <LogIn setUser={setUser}/>
      }
      
    </div>
  );
}

export default App;
