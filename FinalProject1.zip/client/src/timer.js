// import { useTimer } from 'use-timer';

// const { time, start, pause, reset, status } = useTimer({
//     initialTime: 100,
//     timerType: 'DECREMENTAL',
//   });

//  export default timer;