import React, {useState, useEffect} from 'react'
import '../../MyCSS.css'
import axios from 'axios'


function User(props) {

    const [permissions, setPermissions] = useState([]);

    useEffect( () => {
        let newPermissions = []

        axios.get("http://localhost:8000/usersWS/perms/" + props.user.id)
        .then( perms => {
            newPermissions = perms.data
            setPermissions(newPermissions)
        })
        .catch(err => console.log(err))
    }, [])


    const deleteUser = () => {
        
        axios.post("http://localhost:8000/usersWS/remove/" + props.user.id)
        .then( perms => {
            props.forceUpdate(n => !n);
        })
    }

    return (
        <div className="user">
        Name: {props.user.fName + ' ' + props.user.lName} <br/>
        User Name: {props.user.username} <br/>
        Session time out (minutes): {props.user.SessionTimeOut} <br/>
        Created date: {props.user.CreatedDate} <br/>
        Permissions: { permissions && permissions.join(', ') } <br/>

        <button onClick={() => props.editUser(props.user.id)}>Edit</button>
        <button onClick={deleteUser}>Delete</button>
        </div>
    );
}

export default User;
