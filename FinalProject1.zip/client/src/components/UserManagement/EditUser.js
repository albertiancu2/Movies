import React, {useState} from 'react'
import { useEffect } from 'react';
import '../../MyCSS.css'
import axios from 'axios'

function EditUser(props) {

    const [errorMsg, setErrorMsg] = useState("")
    const [newUser, setNewUser] = useState(
        {  
            fName: '',
            lName: '',
            username: '',
            CreatedDate: '',
            SessionTimeOut: '',
        }
    )

    const [permissions, setPermissions] = useState([
        {value: "View Subscriptions", isChecked: false},
        {value: "Create Subscriptions", isChecked: false}, 
        {value: "Delete Subscriptions", isChecked: false}, 
        {value: "Update Subscriptions", isChecked: false},
        {value: "View Movies", isChecked: false},
        {value: "Create Movies", isChecked: false},
        {value: "Delete Movies", isChecked: false},
        {value: "Update Movies", isChecked: false},
   ])

   let checkboxList = permissions.map( (c, index) => {
        return (
            <div key={index}>
                <label>
                    <input type="checkbox"
                        checked={c.isChecked}
                        onChange={() => {
                            let newPermissions = permissions.slice()
                            newPermissions[index] = {...c, isChecked: !c.isChecked}
                            if (c.isChecked === false) {
                                if (index === 1 || index === 2 || index === 3) {
                                newPermissions[0] = {...permissions[0], isChecked: !c.isChecked}
                                }
                                else if (index === 5 || index === 6 || index === 7) {
                                    newPermissions[4] = {...permissions[4], isChecked: !c.isChecked}
                                }
                            }
                            setPermissions(newPermissions)
                    
                        }}
                    />
                    {c.value}
                </label>
                <br/>
            </div>
        );
    });

   useEffect( () => {
       axios.get("http://localhost:8000/usersWS/data/" + props.match.params.id)
        .then(ans => {
            setNewUser(ans.data)
            axios.get("http://localhost:8000/usersWS/perms/" + props.match.params.id)
                .then(perms => {
                    let newPermissions = permissions.map( per => {
                        if (perms.data.includes(per.value)) {
                            return ({...per, isChecked: true})
                        }
                        else {
                            return ({...per, isChecked: false})
                        }
                    })
                    setPermissions(newPermissions);
                })
        })

   }, [])


   const insertUser = (e) => {
        e.preventDefault();

        if (newUser.username === "") {
            setErrorMsg("ERROR! need to provide user name!!!")
        }
        else {
            let dataToInsert = {...newUser}
            let permissionsList = permissions.filter( per => per.isChecked);
            permissionsList = permissionsList.map( per => per.value);
            
            axios.post("http://localhost:8000/usersWS/edit/" + props.match.params.id, { data: dataToInsert, permissions: permissionsList})
                .then( res => 
                    {
                        debugger
                        goToAllUsers()
                    })
                .catch( err => {
                    debugger
                    setErrorMsg(err.data)
                })
                 
        }
           
   

   }

   const goToAllUsers = () => {
       debugger
       props.changeYellowBtn('/users');
        props.history.push('/users');
   }

    return (
        <div className="usersMan">
            <h3>Add New User</h3>
            <p className="errorMsg">{errorMsg}</p>
            <form onSubmit={insertUser}>
                First Name: <input type="text" value={newUser.fName} onChange={ e => setNewUser({...newUser, fName: e.target.value})}></input> <br/>
                Last Name: <input type="text" value={newUser.lName} onChange={ e => setNewUser({...newUser, lName: e.target.value})}></input> <br/>
                User Name: {newUser.username} <br/>
                Session Time out (minutes): <input type="text" value={newUser.SessionTimeOut} onChange={ e => setNewUser({...newUser, SessionTimeOut: e.target.value})}></input> <br/>
                Created Date: {newUser.CreatedDate} <br/>

                Permissions: <br/>
                {checkboxList}
                <input type="submit" value="Save" /> <input type="button" value="Cancel" onClick={goToAllUsers}/> 
            </form>
           
        </div>
    );
}

export default EditUser;
