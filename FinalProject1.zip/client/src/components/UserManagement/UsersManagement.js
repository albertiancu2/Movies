import {React, useEffect, useState} from 'react'
import {Link, Switch, Route, useHistory} from 'react-router-dom'
import AllUsers from './AllUsers'
import AddUser from './AddUser'
import EditUser from './EditUser'



function UsersManagement(props) {

  const [yellowBtn, setYellowBtn] = useState('');

  const history = useHistory();

  useEffect(() => {
      setYellowBtn(window.location.pathname);
  }, [])

  const goToPage = (url) => {
    history.push(url);
    setYellowBtn(url);
  }


  return (
    <div>
      <h2>Users</h2>
      <button className={yellowBtn === `${props.match.url}` ? 'yellowBG' : ''} onClick={() => goToPage(`${props.match.url}`)}>All Users</button>
      <button className={yellowBtn === `${props.match.url}/adduser` ? 'yellowBG' : ''} onClick={() => goToPage(`${props.match.url}/adduser`)}>Add User</button>
      <br/>
      <br/>
      <Switch>
          <Route path={`${props.match.url}/addUser`} component={p => <AddUser {...p} changeYellowBtn={setYellowBtn}/>}/>
          <Route path={`${props.match.url}/editUser/:id`} component={p => <EditUser {...p} changeYellowBtn={setYellowBtn}/>}/>
          <Route path={`${props.match.url}/`} component={AllUsers}/>
      </Switch>
      

    </div>
  );
}

export default UsersManagement;
