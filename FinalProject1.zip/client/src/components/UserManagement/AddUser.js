import React, {useState} from 'react'
import '../../MyCSS.css'
import axios from 'axios'


function AddUser(props) {

    const [errorMsg, setErrorMsg] = useState("")
    const [newUser, setNewUser] = useState(
        {  
            fName: '',
            lName: '',
            username: '',
            CreatedDate: '',
            SessionTimeOut: ''
        }
    )

    const [permissions, setPermissions] = useState([
        {value: "View Subscriptions", isChecked: false},
        {value: "Create Subscriptions", isChecked: false}, 
        {value: "Delete Subscriptions", isChecked: false}, 
        {value: "Update Subscriptions", isChecked: false},
        {value: "View Movies", isChecked: false},
        {value: "Create Movies", isChecked: false},
        {value: "Delete Movies", isChecked: false},
        {value: "Update Movies", isChecked: false},
   ])

   let checkboxList = permissions.map( (c, index) => {
        return (
            <div key={index}>
                <label>
                    <input type="checkbox"
                        checked={c.isChecked}
                        onChange={() => {
                            let newPermissions = permissions.slice()
                            newPermissions[index] = {...c, isChecked: !c.isChecked}
                            if (c.isChecked === false) {
                                if (index === 1 || index === 2 || index === 3) {
                                newPermissions[0] = {...permissions[0], isChecked: !c.isChecked}
                                }
                                else if (index === 5 || index === 6 || index === 7) {
                                    newPermissions[4] = {...permissions[4], isChecked: !c.isChecked}
                                }
                            }
                            setPermissions(newPermissions)
                      
                        }}
                    />
                    {c.value}
                </label>
                <br/>
            </div>
        
        );
   });


   const insertUser = (e) => {
        e.preventDefault();

        if (newUser.username === "") {
            setErrorMsg("ERROR! need to provide user name!!!")
        }
        else {

            let today = new Date()
            let dataToInsert = {...newUser, CreatedDate: today.getDate() + '/' + (today.getMonth()+1) + '/' + today.getFullYear() }
            let permissionsList = permissions.filter( per => per.isChecked);
            permissionsList = permissionsList.map( per => per.value);
            
            axios.post("http://localhost:8000/usersWS/add", {username: newUser.username, data: dataToInsert, permissions: permissionsList})
				.then( res => {
                    if (res.data === "username already exists") {
                        setErrorMsg(res.data)
                    }
                    else {
                        goToAllUsers()
                    }
                
                } )
                .catch( err => setErrorMsg(err))
        }

   }

   const goToAllUsers = () => {
        props.changeYellowBtn('/users');
        props.history.push('/users');
   }

    return (
        <div className="usersMan">
            <h3>Add New User</h3>
            <p className="errorMsg">{errorMsg}</p>
            <form onSubmit={insertUser}>
                First Name: <input type="text" onChange={ e => setNewUser({...newUser, fName: e.target.value})}></input> <br/>
                Last Name: <input type="text" onChange={ e => setNewUser({...newUser, lName: e.target.value})}></input> <br/>
                User Name: <input type="text" onChange={ e => setNewUser({...newUser, username: e.target.value})}></input> <br/>
                Session Time out (minutes): <input type="text" onChange={ e => setNewUser({...newUser, SessionTimeOut: e.target.value})}></input> <br/>
                Permissions: <br/>
                {checkboxList}
                <input type="submit" value="Save" /> <input type="button" value="Cancel" onClick={goToAllUsers}/> 
            </form>
           
        </div>
    );
}

export default AddUser;
