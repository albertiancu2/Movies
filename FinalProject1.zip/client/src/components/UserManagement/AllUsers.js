import {React, useEffect, useState} from 'react'
import {Link, Switch, Route, useHistory} from 'react-router-dom'
import User from './User'
import axios from 'axios'


function AllUsers(props) {

    const [users, setUsers] = useState([])
    const [a, forceUpdate] = useState(0);

    useEffect( () => {
        let newUsers = []

        axios.get("http://localhost:8000/usersWS/")
        .then( users => {
            newUsers = users.data
            setUsers(newUsers)
        })
        .catch(err => console.log(err))

    }, [])

    useEffect( () => {
        let newUsers = []

        axios.get("http://localhost:8000/usersWS/")
        .then( users => {
            newUsers = users.data
            setUsers(newUsers)
        })
        .catch(err => console.log(err))

    }, [a])

    const editUser = (id) => {
        props.history.push(`/users/editUser/` + id)
    }

    return (
        <div className="usersMan">
        <h3>All Users</h3>
        {
            users.map((u, index) => {
                if (u.username !== 'admin')
                    return <User key={index} user={u} editUser={editUser} forceUpdate={e => forceUpdate(e)}/>
            })
        }
        </div>
    );

}

export default AllUsers;
