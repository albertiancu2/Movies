import React, {useState, useEffect, useContext} from 'react'
import {Link, Switch, Route, useHistory} from 'react-router-dom'
import LogIn from './LogIn'
import '../MyCSS.css'
import axios from 'axios'
//Pages
import Movies from './Movie/Movies'
import Subs from './Subscription/Subs'
import UsersManagement from './UserManagement/UsersManagement'


function MainPage(props) {

    const [currentUser, setCurrentUser] = useState({});
    const [yellowBtn, setYellowBtn] = useState('');

    const history = useHistory();

    const logOut = () => {
        localStorage.removeItem('username')
        localStorage.removeItem('userID')
        props.setUser({username: ''})
        goToPage('/')
    }
    
    useEffect( () => {
        setYellowBtn(window.location.pathname);

        let currUsername = localStorage.getItem('username')
        let currUserId = localStorage.getItem('userID')

        axios.get("http://localhost:8000/usersWS/data/" + currUserId)
            .then(userData => 
                {
                    let currUserData = userData.data

                    if (currUserData.fName === undefined) {
                        currUserData.fName = ''
                    }
                    if (currUserData.lName === undefined) {
                        currUserData.lName = ''
                    }
                    
                    
                    if (currUsername === "admin") {
                        setCurrentUser({id: currUserId, username:currUsername, permissions: "ALL", data: currUserData})
                    }
                    else {
                        axios.get("http://localhost:8000/usersWS/perms/" + currUserId)
                        .then( perms => {
                            setTimeout(() => {
                                alert("Session expired!!!")
                                logOut();
                              }, currUserData.SessionTimeOut*1000*60);
                            setCurrentUser({id: currUserId, username:currUsername, permissions: perms.data, data: currUserData})
                        })
                        .catch(err => console.log(err))
                    }
                  
                })
            .catch(err => console.log(err))
                    
    }, [])

    const goToPage = (url) => {
        history.push(url);
        setYellowBtn(url);
    }

    return (
        <div>
            <h2>Hello {currentUser.data?.fName + ' ' + currentUser.data?.lName}!</h2>

            {
                (currentUser.username === 'admin' || currentUser.permissions?.includes("View Movies")) &&
                <button className={yellowBtn.startsWith('/movies') ? 'yellowBG' : ''} onClick={() => goToPage('/movies')}>Movies</button>
            }

            {
                (currentUser.username === 'admin' || currentUser.permissions?.includes("View Subscriptions")) &&
                <button className={yellowBtn.startsWith('/subs') ? 'yellowBG' : ''} onClick={() => goToPage('/subs')}>Subscriptions</button>
            }
        
            {
                currentUser.username === 'admin'  &&
                <button className={yellowBtn.startsWith('/users')  ? 'yellowBG' : ''} onClick={() => goToPage('/users')}>Users Management</button>
            }

            
            
            <button onClick={logOut}>Log out</button>

            <br/>
            <Switch>
                    <Route path="/movies" component={(props) => <Movies {...props} setMainPageYellow={setYellowBtn} userPermissions={currentUser.permissions} currentUser={currentUser}/>}/>
                    <Route path="/subs" component={(props) => <Subs {...props} setMainPageYellow={setYellowBtn} userPermissions={currentUser.permissions} currentUser={currentUser}/>}/>
                    <Route path="/users" component={UsersManagement}/>
            </Switch>
        </div>
    );
}

export default MainPage;
