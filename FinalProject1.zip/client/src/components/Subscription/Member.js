import React, {useState, useEffect} from 'react'

import {Link} from 'react-router-dom'
import '../../MyCSS.css'
import axios from 'axios'
import AddSubcription from './AddSubscription'


function Member(props) {

    const [moviesWatched, setMoviesWatched] = useState([])
    const [showSubscribePage, setShowSubcribePage] = useState(false)


    const deleteMember = () => {
    
       axios.post('http://localhost:8000/membersWS/remove/', {memberID: props.member._id.toString()})
        .then( ans => {
            props.forceUpdate();
        })
    }

    useEffect(() => {
        loadSupcriptions();
    }, [])


    const loadSupcriptions = () => {
        setShowSubcribePage(false)


        axios.get('http://localhost:8000/subsWS/subs/' + props.member._id)
            .then( async movies => {

                let newMoviesWatched = await Promise.all( movies.data.map( async m => {
                    let currMovie = await axios.get("http://localhost:8000/moviesWS/" + m.movieId)
                    
                    return {...m, name: currMovie.data.name}
                }))

                setMoviesWatched(newMoviesWatched)
                
                
            })
            .catch( err => {
                console.log(err)
            })

        
    }

    return (
        <div className="user">
            <p><b>{props.member.name}</b></p>
            Email: {props.member.email} <br/> 
            City: {props.member.city} <br/> <br/> 
            {
                (props.currentUser.username === 'admin' || props.currentUser.permissions?.includes("Update Subscriptions")) &&
                <button onClick={() => props.editMember(props.member._id)}>Edit</button>
            }
            {
                (props.currentUser.username === 'admin' || props.currentUser.permissions?.includes("Delete Subscriptions")) &&
                <button onClick={deleteMember}>Delete</button>
            }
            {
                (props.currentUser.username === 'admin' || props.currentUser.permissions?.includes("View Movies")) &&
                <div className="moviesWatched">
                    <p><b>Movies Watched</b></p>
                    <button onClick={() => setShowSubcribePage(true)}>Subscribe to new movie</button>
                    {
                        showSubscribePage &&
                        <AddSubcription
                            moviesWatched={moviesWatched} 
                            member={props.member}
                            forceUpdate={() => loadSupcriptions()} 
                        />
                    }
                    <ul>
                        {
                            moviesWatched.map((m, index) => {
                                return (
                                    <li key={index}>
                                        <Link to={`/movies/${m.movieId}`}>{m.name}</Link>, {m.date}
                                    </li>
                                )
                            })
                        }
                    </ul>
                
                </div>
            }
            
            

            

        </div>
    );
}

export default Member;
