import React, {useState, useEffect} from 'react'
import Select from 'react-select'

import '../../MyCSS.css'
import axios from 'axios'


function AddSubcription(props) {

    const [moviesList, setMoviesList] = useState([])

   const [selected, setSelected] = useState([])
   const [dateWatched, setDateWatched] = useState('')

    useEffect( () => {
        let newMovies = []

        axios.get("http://localhost:8000/moviesWS/")
            .then(movies => {
                movies.data.forEach(m => {
                    if (!props.moviesWatched.includes(m._id)) {
                        newMovies.push({label: m.name, value: m._id})
                    }
                })
                setMoviesList(newMovies);
            })

    }, [])


    const subscribeToMovie = () => {
        let formatedDate = dateWatched.split('-')
        formatedDate = formatedDate[2] + '/' + formatedDate[1] + '/' + formatedDate[0]

        axios.post("http://localhost:8000/subsWS/add", {memberID: props.member._id, movieID: selected.value, date: formatedDate})
            .then(ans => {
                props.forceUpdate(n => !n);
            })
    }

    return (
        <div className="user">
                <Select
                    options={moviesList}
                    onChange={setSelected}
                    labelledBy={"Select"}
                />
                <input type="date" data-date-format="DD MMMM YYYY" onChange={e => setDateWatched(e.target.value)}/>
                <button onClick={subscribeToMovie}>Subscribe</button>

        </div>
    );
}

export default AddSubcription;
