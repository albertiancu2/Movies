import React, {useState, useEffect} from 'react'
import {Link, Switch, Route, useHistory} from 'react-router-dom'
import AllMembers from './AllMembers'
import AddMember from './AddMember'
import EditMember from './EditMember'
import '../../MyCSS.css'


function Subs(props) {

  const [yellowBtn, setYellowBtn] = useState('');

  const history = useHistory();

  useEffect(() => {
      setYellowBtn(window.location.pathname);
  }, [])

  const goToPage = (url) => {
    history.push(url);
    setYellowBtn(url);
  }

  return (
    <div>
      <h2>Subscriptions</h2>
      <button className={yellowBtn === `${props.match.url}` ? 'yellowBG' : ''} onClick={() => goToPage(`${props.match.url}`)}>All Members</button>
      {
        (props.currentUser.username === 'admin' || props.currentUser.permissions?.includes('Create Movies')) &&
        <button className={yellowBtn === `${props.match.url}/addmember` ? 'yellowBG' : ''} onClick={() => goToPage(`${props.match.url}/addmember`)}>Add Member</button>
      }
      <br/>
      <br/>
      <Switch>
          <Route path={`${props.match.url}/addmember`} component={p => <AddMember {...p} changeYellowBtn={setYellowBtn}/>}/>
          <Route path={`${props.match.url}/editmember/:id`} component={p => <EditMember {...p} changeYellowBtn={setYellowBtn}/>}/>
          <Route path={`${props.match.url}/:id`} component={(p) => <AllMembers {...p}  changeYellowBtn={setYellowBtn} setMainPageYellow={props.setMainPageYellow} currentUser={props.currentUser}/>}/>
          <Route path={`${props.match.url}/`} component={(p) => <AllMembers {...p} changeYellowBtn={setYellowBtn} setMainPageYellow={props.setMainPageYellow} currentUser={props.currentUser}/>}/>
      </Switch>
      
    </div>
  );
}

export default Subs;
