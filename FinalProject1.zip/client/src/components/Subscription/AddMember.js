import React, {useState} from 'react'

import '../../MyCSS.css'
import axios from 'axios'

function AddMember(props) {

    const [errorMsg, setErrorMsg] = useState("")
    const [newMember, setNewMember] = useState(
        {  
            id: "",
            name: "",
            email: "",
            city: "",
        }
    )


   const insertMember = (e) => {
        e.preventDefault();

        if (newMember.name === "") {
            setErrorMsg("ERROR! need to provide Member name!!!")
        }
        else {
            debugger
            axios.post("http://localhost:8000/membersWS/add", {member: newMember})
                .then(ans => {
                    goToAllMembers()
                })
                .catch(err => {
                    setErrorMsg(err)
                })
          
        }

   }

   const goToAllMembers = () => {
        props.changeYellowBtn('/subs')
        props.history.push('/subs');
   }

    return (
        <div className="usersMan">
            <h3>Add New Member</h3>
            <p className="errorMsg">{errorMsg}</p>
            <form onSubmit={insertMember}>
                Name: <input type="text" onChange={ e => setNewMember({...newMember, name: e.target.value})}></input> <br/>
                Email: <input type="text" onChange={ e => setNewMember({...newMember, email: e.target.value})}></input> <br/>
                City: <input type="text" onChange={ e => setNewMember({...newMember, city: e.target.value})}></input> <br/>
                <input type="submit" value="Save" /> <input type="button" value="Cancel" onClick={goToAllMembers}/> 
            </form>
        </div>
    );
}

export default AddMember;
