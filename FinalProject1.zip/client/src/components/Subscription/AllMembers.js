import React, {useState, useEffect} from 'react'
import '../../MyCSS.css'
import Member from './Member'
import axios from 'axios'



function AllMembers(props) {

    const [members, setMembers] = useState([])

    useEffect( () => {
        
        // Utils.getMembersFromServer(); //Only once!!! at the very beginning!!!

        props.changeYellowBtn('/subs')
        props.setMainPageYellow('/subs')

        loadAllMembers();

    }, [])

    // useEffect( () => {      
    //     props.changeYellowBtn('/subs')
    //     props.setMainPageYellow('/subs')
    //      loadAllMembers();
        
    // }, [a])

    const loadAllMembers = () => {
        if (!props.match.params.id) {
            let newMembers = []

            axios.get("http://localhost:8000/membersWS/")
            .then( ans => {
        
                ans.data.forEach(m => {
                    newMembers.push(m)
                });
                setMembers(newMembers);
                
            });

        }
        else {
            axios.get("http://localhost:8000/membersWS/" + props.match.params.id)
            .then( ans => {
                setMembers([ans.data])
            })

        }
    }

    const editMember = (id) => {
        props.history.push(`/subs/editmember/` + id)
    }

    return (
        <div className="usersMan">
        <h3>All Members</h3>
        {
            members.map((m, index) => {
                return (
                    <Member 
                        key={m._id} 
                        member={m} 
                        forceUpdate={() => loadAllMembers()} 
                        editMember = {editMember}
                        userPermissions={props.userPermissions}
                        currentUser={props.currentUser}
                    />
                )
    
            })
        }
        </div>
    );
}

export default AllMembers;
