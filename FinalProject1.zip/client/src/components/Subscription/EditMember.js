import React, {useState, useEffect} from 'react'

import '../../MyCSS.css'
import axios from 'axios'

function EditMember(props) {

    const [errorMsg, setErrorMsg] = useState("")
    const [newMember, setNewMember] = useState(
        {  
            id: "",
            name: "",
            email: "",
            city: "",
        }
    )


    useEffect(() => {
        axios.get("http://localhost:8000/membersWS/" + props.match.params.id)
                .then(mem => {
                    debugger
                    setNewMember(mem.data)
                })
                .catch(err => {
                    setErrorMsg(err)
                }) 

   }, [])



   const insertMember = (e) => {
        e.preventDefault();

        if (newMember.name === "") {
            setErrorMsg("ERROR! need to provide Member name!!!")
        }
        else {

            axios.post("http://localhost:8000/membersWS/update", {id: props.match.params.id, member: newMember})
                .then(mem => {
                    goToAllMembers();
                })
                .catch(err => {
                    setErrorMsg(err)
                }) 
        }

   }

   const goToAllMembers = () => {
        props.changeYellowBtn('/subs')
        props.history.push('/subs');
   }

    return (
        <div className="usersMan">
            <h3>Add New Member</h3>
            <p className="errorMsg">{errorMsg}</p>
            <form onSubmit={insertMember}>
                Name: <input type="text" value={newMember.name} onChange={ e => setNewMember({...newMember, name: e.target.value})}></input> <br/>
                Email: <input type="text" value={newMember.email} onChange={ e => setNewMember({...newMember, email: e.target.value})}></input> <br/>
                City: <input type="text" value={newMember.city} onChange={ e => setNewMember({...newMember, city: e.target.value})}></input> <br/>
                <input type="submit" value="Update" /> <input type="button" value="Cancel" onClick={goToAllMembers}/> 
            </form>
        </div>
    );
}

export default EditMember;
