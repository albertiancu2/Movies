import React, {useState, useEffect} from 'react'
import {Link, Redirect} from 'react-router-dom'
import axios from 'axios'

function Signup(props) {

    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const [errorMsg, setErrorMsg] = useState("");

    const userSignup = (e) => {

        e.preventDefault();

        if (password.length < 4) {
            setErrorMsg("Password need to be at least 4 characters!!!")
            return
        }

        axios.post("http://localhost:8000/usersWS/signup", {username: username, password: password})
        .then(
            resp =>
            {
                if (resp.data.state != "OK") {
                    debugger
                    setErrorMsg(resp.data.msg)
                }
                else {
                    debugger
                    localStorage.setItem('username', username)
                    localStorage.setItem('userID', resp.data.userId)
                    props.setUser({username: username})
                }
            } 
        )
        .catch(
            err => alert(err)
        )

    }

    return (
        <div>
            <h2>Create an Account</h2>
            User name: <input type="text" onChange={e => setUsername(e.target.value)}/> <br/>
            Password: <input type="text" onChange={e => setPassword(e.target.value)}/> <br/>
            <p style={{color: "red"}}>{errorMsg}</p>
           
            <div>
                <input type="button" value="Create" onClick={userSignup}/>
            </div>
    
        </div>
    );
}

export default Signup;
