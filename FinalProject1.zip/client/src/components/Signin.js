import React, {useState, useEffect} from 'react'
import {Link, Redirect} from 'react-router-dom'
import axios from 'axios'
import axiosCookieJarSupport from 'axios-cookiejar-support'
import tough from 'tough-cookie'
import { useIdleTimer } from 'react-idle-timer'
import { Timer } from 'timer-node';
import { useTimer } from 'use-timer';


function Signin(props) {

    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const [errorMsg, setErrorMsg] = useState("");

    // axios.defaults.withCredentials = true

    const userLogin = (e) => {
        e.preventDefault();
        axios.post("http://localhost:8000/usersWS/login/", {username: username, password: password})
        .then(
            resp =>
            {
                if (resp.data.state != "OK") {
                    setErrorMsg(resp.data.msg)
                }
                else {
                    localStorage.setItem('username', username)
                    localStorage.setItem('userID', resp.data.userId)
                    props.setUser({username: username})
                }
            } 
        )
        .catch(
            err => alert(err)
        )
       
    }

    return (
        <div>
            <h2>Log in page</h2>
            <form onSubmit={userLogin}>
                User name: <input type="text" onChange={e => setUsername(e.target.value)}/> <br/>
                Password: <input type="text" onChange={e => setPassword(e.target.value)}/> <br/>
                <p style={{color: "red"}}>{errorMsg}</p>

                <div>
                    <input type="submit" value="Login" /> <br/>
                    New User? <Link to='/signup'>Create Account</Link>
                </div>
            </form>

                
        </div>
    );
}

export default Signin;
