import React, {useState, useEffect} from 'react'
import {Link, Route, Switch} from 'react-router-dom'
import {Redirect} from 'react-router-dom'
import Signin from './Signin'
import Signup from './Signup'
import axios from 'axios'


function LogIn(props) {

    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const [errorMsg, setErrorMsg] = useState("");
    const [hasAccount, setHasAccount] = useState(true);

    return (
        <div>
            <Switch>
                <Route path="/signup" component={() => <Signup setUser={props.setUser}/>}/>
                <Route path="/" component={() => <Signin setUser={props.setUser}/>}/>
            </Switch>
        
        </div>
    );
}

export default LogIn;
