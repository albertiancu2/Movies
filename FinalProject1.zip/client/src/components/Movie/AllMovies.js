import React, {useState, useEffect} from 'react'
import '../../MyCSS.css'
import axios from 'axios'
import Movie from './Movie'





function AllMovies(props) {

    const [movies, setMovies] = useState([])

    useEffect( () => {

        props.changeYellowBtn('/movies')
        props.setMainPageYellow('/movies')

        loadAllMovies();


    }, [])

 
    // useEffect( () => {

    //     props.changeYellowBtn('/movies')
    //     props.setMainPageYellow('/movies')

    // loadAllMovies();


    // }, [a])


    const loadAllMovies = () => {

        if (!props.match.params.id) {
            let newMovies = []

            axios.get("http://localhost:8000/moviesWS/")
            .then( ans => {
                if (props.searchMovie === '') {
                    ans.data.forEach(m => {
                        newMovies.push(m)
                    });
                    setMovies(newMovies);
                }
                else {
                    ans.data.filter(m => 
                        m.name.toLowerCase().includes(props.searchMovie.toLowerCase())
                    )
                    .forEach(m => {
                        newMovies.push(m)
                    });
                    setMovies(newMovies);
                }
            });

        }
        else {
            axios.get("http://localhost:8000/moviesWS/" + props.match.params.id)
            .then( ans => {
                if (ans.data === 'no member with give ID') {
                    setMovies([])
                }
                else {
                    setMovies([ans.data])
                }
                
            })


        }
       
    }


    const editMovie = (id) => {
        props.history.push(`/movies/editmovie/` + id)
    }


    return (
        <div>
        {
            <div className="usersMan">
        
            <h3>All Movies</h3>
            {
                movies.map((m, index) => {
                    return (
                        <Movie 
                            key={m._id} 
                            movie={m} 
                            forceUpdate={() => loadAllMovies()} 
                            editMovie = {editMovie}
                            userPermissions={props.userPermissions}
                            currentUser={props.currentUser}
                        />
                    )
        
                })
            }
            </div>
        }
            
        </div>
        
    );
}

export default AllMovies;
