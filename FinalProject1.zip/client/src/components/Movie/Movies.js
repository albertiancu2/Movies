import React, {useState, useEffect} from 'react'
import {Link, Switch, Route, useHistory} from 'react-router-dom'
import AllMovies from './AllMovies'
import AddMovie from './AddMovie'
import EditMovie from './EditMovie'
import '../../MyCSS.css'


function Movies(props) {

  const [yellowBtn, setYellowBtn] = useState('');
  const [showMoviesText, setShowMoviesText] = useState('');

  let searchText = ''; //We don't want a page to re-render each time this text changes!!

  const history = useHistory();

  useEffect(() => {
      setYellowBtn(window.location.pathname);
  }, [])

  const goToPage = (url) => {
    history.push(url);
    setYellowBtn(url);
  }

  return (
    <div>
      <h2>Movies</h2>
      <button className={yellowBtn === `${props.match.url}` ? 'yellowBG' : ''} onClick={() => goToPage(`${props.match.url}`)}>All Movies</button>
      {
        (props.currentUser.username === 'admin' ||  props.currentUser.permissions?.includes('Create Movies')) &&
        <button className={yellowBtn === `${props.match.url}/addmovie` ? 'yellowBG' : ''} onClick={() => goToPage(`${props.match.url}/addmovie`)}>Add Movie</button>
      }
      <input type="text" onChange={e => searchText = e.target.value}/>
      <button onClick={() => {
        setShowMoviesText(searchText)
        goToPage('/movies')
      }}>Find</button>
      <br/>
      <br/>
      <Switch>
          <Route path={`${props.match.url}/addmovie`} component={p => <AddMovie {...p} setMainPageYellow={props.setMainPageYellow} changeYellowBtn={setYellowBtn}/>}/>
          <Route path={`${props.match.url}/editmovie/:id`} component={p => <EditMovie {...p} setMainPageYellow={props.setMainPageYellow} changeYellowBtn={setYellowBtn}/>}/>
          <Route path={`${props.match.url}/:id`} component={(p) => <AllMovies {...p} setMainPageYellow={props.setMainPageYellow} changeYellowBtn={setYellowBtn} searchMovie={showMoviesText} currentUser={props.currentUser}/>}/>
          <Route path={`${props.match.url}/`} component={(p) => <AllMovies {...p} setMainPageYellow={props.setMainPageYellow} changeYellowBtn={setYellowBtn} searchMovie={showMoviesText} currentUser={props.currentUser}/>}/>
      </Switch>
      
    </div>
  );
}

export default Movies;
