import React, {useState} from 'react'
import { useEffect } from 'react';
import MultiSelect from "react-multi-select-component";
import '../../MyCSS.css'
import axios from 'axios'
import { date } from 'yup';

function EditMovie(props) {

    const [errorMsg, setErrorMsg] = useState("")
    const [newMovie, setNewMovie] = useState(
        {  
            name: "",
            genres: "",
            image: {medium: ""},
            premiered: ""
        }
    )

    const [selected, setSelected] = useState([]);

   const genres = [
    { label: "Drama" , value: "Drama"},
    { label: "Comedy", value: "Comedy" },
    { label: "Thriller" , value: "Thriller"},
    { label: "Mistery" , value: "Mistery"},
    { label: "Horror", value: "Horror" },
    { label: "Romance", value: "Romance" },
    { label: "Action", value: "Action" },
    { label: "Fantasy", value: "Fantasy" },
    { label: "Science Fiction", value: "Science Fiction" },
    { label: "Documentary", value: "Documentary" },
  ];


  useEffect(() => {
    axios.get('http://localhost:8000/moviesWS/' + props.match.params.id)
    .then( async movie => {
        let newGenres = movie.data.genres.map( item => {
          return {label: item, value: item}
        } );
        let d = new Date(movie.data.premiered)
        let m = {...movie.data , premiered: d.getFullYear().toString() + '-' + ("0" + (d.getMonth() + 1)).slice(-2) + '-' + ("0" + d.getDate()).slice(-2)}
        debugger
        setSelected(newGenres)  
        setNewMovie(m)
    })
    .catch( err => {
        console.log(err)
    })
  }, [])


   const insertMovie = (e) => {

      e.preventDefault();

      if (newMovie.name === "") {
          setErrorMsg("ERROR! need to provide Movie name!!!")
      }
      else {
          let genresList = selected.map( item => item.value)
          let movieToInsert = {...newMovie, genres: genresList}

          axios.post("http://localhost:8000/moviesWS/update/", {id: props.match.params.id, movie: movieToInsert})
            .then(ans => {
              goToAllMovies();
            })
      }

   }

   const goToAllMovies = () => {
        props.changeYellowBtn('/movies')
        props.history.push('/movies');
   }

    return (
        <div className="usersMan">
            <h3>Edit Movie</h3>
            <p className="errorMsg">{errorMsg}</p>
            <form onSubmit={insertMovie}>
                Name: <input type="text" value={newMovie.name} onChange={ e => setNewMovie({...newMovie, name: e.target.value})}></input> <br/>
                {/* Genres: <input type="text" onChange={ e => setNewMovie({...newMovie, genres: e.target.value})}></input> <br/> */}
                Genres:        
                <MultiSelect
                    options={genres}
                    value={selected}
                    onChange={setSelected}
                    labelledBy={"Select"}
                />
                Image URL: <input type="text" value={newMovie.image} onChange={ e => setNewMovie({...newMovie, image: {medium: e.target.value}})}></input> <br/>
                Premiered: <input type="date" value={newMovie.premiered} onChange={ e => setNewMovie({...newMovie, premiered: e.target.value})}></input> <br/>
                <input type="submit" value="Save" /> <input type="button" value="Cancel" onClick={goToAllMovies}/> 
            </form>
        </div>
    );
}

export default EditMovie;
