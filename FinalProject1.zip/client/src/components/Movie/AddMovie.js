import React, {useState} from 'react'
import { useEffect } from 'react';
import MultiSelect from "react-multi-select-component";
import '../../MyCSS.css'
import axios from 'axios'

function AddMovie(props) {

    const [errorMsg, setErrorMsg] = useState("")
    const [newMovie, setNewMovie] = useState(
        {  
            name: "",
            genres: "",
            image: {medium: ""},
            premiered: ""
        }
    )

    const [selected, setSelected] = useState([]);

   const genres = [
    { label: "Drama" , value: "Drama"},
    { label: "Comedy", value: "Comedy" },
    { label: "Thriller" , value: "Thriller"},
    { label: "Mistery" , value: "Mistery"},
    { label: "Horror", value: "Horror" },
    { label: "Romance", value: "Romance" },
    { label: "Action", value: "Action" },
    { label: "Fantasy", value: "Fantasy" },
    { label: "Science Fiction", value: "Science Fiction" },
    { label: "Documentary", value: "Documentary" },
  ];


   const insertMovie = (e) => {
        e.preventDefault();

        if (newMovie.name === "") {
            setErrorMsg("ERROR! need to provide Movie name!!!")
        }
        else {
            let genresList = selected.map( item => item.value)
            let movieToInsert = {...newMovie, genres: genresList}

            axios.post("http://localhost:8000/moviesWS/add/", {movie: movieToInsert})
              .then(ans => {
                goToAllMovies();
              })
        }

   }

   const goToAllMovies = () => {
        props.changeYellowBtn('/movies')
        props.history.push('/movies');
   }

    return (
        <div className="usersMan">
            <h3>Add New Movie</h3>
            <p className="errorMsg">{errorMsg}</p>
            <form onSubmit={insertMovie}>
                Name: <input type="text" onChange={ e => setNewMovie({...newMovie, name: e.target.value})}></input> <br/>
                Genres:        
                <MultiSelect
                    options={genres}
                    value={selected}
                    onChange={setSelected}
                    labelledBy={"Select"}
                />
                Image URL: <input type="text" onChange={ e => setNewMovie({...newMovie, image: e.target.value})}></input> <br/>
                Premiered: <input type="date" onChange={ e => setNewMovie({...newMovie, premiered: e.target.value})}></input> <br/>
                <input type="submit" value="Save" /> <input type="button" value="Cancel" onClick={goToAllMovies}/> 
            </form>
        </div>
    );
}

export default AddMovie;
