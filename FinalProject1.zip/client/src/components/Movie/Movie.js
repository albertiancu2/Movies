import React, {useState, useEffect} from 'react'
import {Link} from 'react-router-dom'
import '../../MyCSS.css'
import axios from 'axios'


function Movie(props) {

    const [subs, setSubs] = useState([]);

    //TODO: show all movie subs!!!
    useEffect(() => {
        axios.get('http://localhost:8000/subsWS/movieSubs/' + props.movie._id)
        .then( async members => {
            let newMemers = await Promise.all( members.data.map( async m => {
                let currMembers = await axios.get("http://localhost:8000/membersWS/" + m.memberId)
                
                return {...m, name: currMembers.data.name}
            }))

            setSubs(newMemers)
            
            
        })
        .catch( err => {
            console.log(err)
        })

    }, [])

    const deleteMovie = () => {
        
        axios.post("http://localhost:8000/moviesWS/remove/", {movieID:  props.movie._id})
            .then(ans => {
                props.forceUpdate();
            })
        
    }

    return (
        <div className="user">
            <p><b>{props.movie.name}, {props.movie.premiered.split('-')[0]}</b></p>
            genres: {props.movie.genres.join(', ')} <br/> <br/>
            <div className="wrapper">
                <div className="first">
                    <img className="image" src={props.movie.image} alt="*Picture undefined*"/>
                </div>

                {
                    (props.currentUser.username === 'admin' || props.currentUser.permissions?.includes("View Subscriptions")) &&
                    <div className="second user">
                        Subscriptions watched
                        <ul>
                            {subs.map( (s, index) => {
                                return (
                                    <li key={index}>
                                        <Link to={`/subs/${s.memberId}`}>{s.name}</Link>, {s.date}
                                    </li>
                                )
                            })}
                        </ul>
                    </div>
                }
              

            </div>

            {
                (props.currentUser.username === 'admin' || props.currentUser.permissions?.includes("Update Movies")) &&
                <button onClick={() => props.editMovie(props.movie._id)}>Edit</button>
            }
            {
                (props.currentUser.username === 'admin' || props.currentUser.permissions?.includes("Delete Movies")) &&
                <button onClick={deleteMovie}>Delete</button>
            }
            
            
            
        

        </div>
    );
}

export default Movie;
