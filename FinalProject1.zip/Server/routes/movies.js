const express = require('express')
const moviesWS = require('../BLs/moviesBL')
const subsWS = require('../BLs/subsBL')

const router = express.Router();

router.route('/').get(async function(req,resp)
{
    let movies = await moviesWS.getAllMovies()
    return resp.json(movies);
})

router.route('/:id').get(async function(req,resp)
{
    let movie = await moviesWS.getMovieByID(req.params.id)
    return resp.json(movie);
})


router.route('/add').post(async function(req,resp)
{
    let ans = await moviesWS.addMovie(req.body.movie)
    return resp.json(ans);
})


router.route('/remove').post(async function(req,resp)
{
    let ans = await moviesWS.removeMovie(req.body.movieID)
    return resp.json(ans);
})


router.route('/update').post(async function(req,resp)
{
    let ans = await moviesWS.updateMovie(req.body.id, req.body.movie);
    return resp.json(ans);
})

module.exports = router;