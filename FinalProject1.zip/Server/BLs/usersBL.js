const usersDAL = require('../DALs/usersDAL')
const userJSON = require('../DALs/usersJSONDAL')
const permissionsDAL = require('../DALs/permissionsJSONDAL')

const mongoose = require('mongoose');
const UsersModel = require('../models/usersModel');
const { use } = require('../routes/users');


// usersDAL.getAllUsers().then(ans => console.log(ans)).catch(err => console.log("error"))
// usersDAL.addUser({username: "aaaa", password: "111111"}).then(ans => console.log(ans)).catch(err => console.log("ERROR", err))
// usersDAL.removeUser("604b8ddff8b2bc58282545b9").then(ans => console.log(ans)).catch(err => console.log("ERROR", err))
// usersDAL.checkLogin("aaaa", "12").then(ans => console.log(ans)).catch(err => console.log("ERROR", err))


exports.getAllUsers = async function()
{
    try {  
        allUsers = await userJSON.getAllUsers()
        return allUsers
    }
     
    catch (err) {
        console.log(err)
    }

}


exports.getUserDataByID = async function(id)
{
    try {
        let user = await userJSON.getUserByID(id);
        return user
    }
    catch (err) {
        console.log(err)
        return err
    }
}


exports.getUserPermissionsByID = async function(id)
{
    try {
        let user = await permissionsDAL.getUserPermissionsByID(id);
        return user
    }
    catch (err) {
        console.log(err)
    }
}



exports.addNewUser = async function(username, data, permissions)
{
    try {
        let currUser = await usersDAL.getUserByUsername(username);
        return "username already exists"
    }
    catch (err) {
        if (err === "username not in DB") {
            try {
                let userId = await usersDAL.addUser({username: username, password: ''})
                await userJSON.addUser({...data, id: userId})
                await permissionsDAL.addUserPemissions({permissions: permissions, id: userId})
                return "OK"
            }
            catch (err) {
                return err
            }
            
            
        }
        else {
            return err
        }
    }
}



exports.newUserPassword = async function(username, password)
{
    try {
        let user = await usersDAL.getUserByUsername(username)
        if (user.password !== '') {
            return {state: "error", msg: "You are already signed up!"}
        }
        else {
            await usersDAL.updateUser(user._id, {username: username, password: password})
            return {state: "OK", userId: user.id}
        }
    }
    catch (err) {
        return {state: "error", msg: err}
    }     
}



exports.updateUser = async function(id, userData, permissions)
{
    try {
        let ans = await userJSON.updateUser({id: id, ...userData});
        await permissionsDAL.updateUserPermissions(id, permissions)
        return ans
    }
    catch (err) {
        console.log(err)
    }
}


exports.updateUserPermissions = async function(id, permissions)
{
    try {
        let ans = await permissionsDAL.updateUserPermissions({id: id, permissions: permissions});
        return ans
    }
    catch (err) {
        console.log(err)
    }
}




exports.removeUser = async function(id)
{
    try {
        let ans = await usersDAL.removeUser(id);
        await userJSON.removeUser(id);
        await permissionsDAL.removeUserPermissions(id);
        return "Deleted"
    }
    catch (err) {
        return err
    }
}


exports.checkLoginCredentials = async function(username, password)
{
    try {
        let usr = await usersDAL.getUserByUsername(username)
        if (usr.password === '') {
            return {state: "error", msg: "You need to sign up fist!!!"}
        }
        else if (usr.password !== password) {
            return {state: "error", msg: "Incorrect Password"}
        }
        else {
            return {state: "OK", userId: usr.id}
        }
    }
    catch (err) {
        return {state: "error", msg: err}
    } 
}



// let ans = this.checkLogin("aadasdasaa", "sad").then(a => console.log(a)).catch(e => console.log("error: ", e))

//--------------------------------------------------------

// let ans = permissionsDAL.getAllUsersPermissions().then(a => console.log(a));
// let ans =  permissionsDAL.getUserPermissionsByID('ssss').then(a => console.log(a));

// let newUser =    {
//     id: "adsasd",
//     permissions: ["xc1", "xc2"]
// }

// permissionsDAL.addUserPemissions(newUser).then(ans => console.log("OK"))
// permissionsDAL.updateUserPermissions(newUser).then(ans => console.log("OK"))
// permissionsDAL.removeUserPermissions('adsasd').then(ans => console.log("OK"))


// usersDAL.addUser({username: 'asdadas', password: 'aaaaaaa'}).then(ans => console.log(ans))

// this.newUserPassword('aaaa', 'asdasd').then(ans => console.log(ans))

// permissionsDAL.getUserPermissionsByID('ssss').then(ans => console.log(ans)).catch(err => console.log(err))